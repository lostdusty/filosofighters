module.exports = {
    "port": 4444,
    "open": "index.html"
}